declare module 'astro:content' {
	export interface RenderResult {
		Content: import('astro/runtime/server/index.js').AstroComponentFactory;
		headings: import('astro').MarkdownHeading[];
		remarkPluginFrontmatter: Record<string, any>;
	}
	interface Render {
		'.md': Promise<RenderResult>;
	}

	export interface RenderedContent {
		html: string;
		metadata?: {
			imagePaths: Array<string>;
			[key: string]: unknown;
		};
	}
}

declare module 'astro:content' {
	type Flatten<T> = T extends { [K: string]: infer U } ? U : never;

	export type CollectionKey = keyof AnyEntryMap;
	export type CollectionEntry<C extends CollectionKey> = Flatten<AnyEntryMap[C]>;

	export type ContentCollectionKey = keyof ContentEntryMap;
	export type DataCollectionKey = keyof DataEntryMap;

	type AllValuesOf<T> = T extends any ? T[keyof T] : never;
	type ValidContentEntrySlug<C extends keyof ContentEntryMap> = AllValuesOf<
		ContentEntryMap[C]
	>['slug'];

	export type ReferenceDataEntry<
		C extends CollectionKey,
		E extends keyof DataEntryMap[C] = string,
	> = {
		collection: C;
		id: E;
	};
	export type ReferenceContentEntry<
		C extends keyof ContentEntryMap,
		E extends ValidContentEntrySlug<C> | (string & {}) = string,
	> = {
		collection: C;
		slug: E;
	};
	export type ReferenceLiveEntry<C extends keyof LiveContentConfig['collections']> = {
		collection: C;
		id: string;
	};

	/** @deprecated Use `getEntry` instead. */
	export function getEntryBySlug<
		C extends keyof ContentEntryMap,
		E extends ValidContentEntrySlug<C> | (string & {}),
	>(
		collection: C,
		// Note that this has to accept a regular string too, for SSR
		entrySlug: E,
	): E extends ValidContentEntrySlug<C>
		? Promise<CollectionEntry<C>>
		: Promise<CollectionEntry<C> | undefined>;

	/** @deprecated Use `getEntry` instead. */
	export function getDataEntryById<C extends keyof DataEntryMap, E extends keyof DataEntryMap[C]>(
		collection: C,
		entryId: E,
	): Promise<CollectionEntry<C>>;

	export function getCollection<C extends keyof AnyEntryMap, E extends CollectionEntry<C>>(
		collection: C,
		filter?: (entry: CollectionEntry<C>) => entry is E,
	): Promise<E[]>;
	export function getCollection<C extends keyof AnyEntryMap>(
		collection: C,
		filter?: (entry: CollectionEntry<C>) => unknown,
	): Promise<CollectionEntry<C>[]>;

	export function getLiveCollection<C extends keyof LiveContentConfig['collections']>(
		collection: C,
		filter?: LiveLoaderCollectionFilterType<C>,
	): Promise<
		import('astro').LiveDataCollectionResult<LiveLoaderDataType<C>, LiveLoaderErrorType<C>>
	>;

	export function getEntry<
		C extends keyof ContentEntryMap,
		E extends ValidContentEntrySlug<C> | (string & {}),
	>(
		entry: ReferenceContentEntry<C, E>,
	): E extends ValidContentEntrySlug<C>
		? Promise<CollectionEntry<C>>
		: Promise<CollectionEntry<C> | undefined>;
	export function getEntry<
		C extends keyof DataEntryMap,
		E extends keyof DataEntryMap[C] | (string & {}),
	>(
		entry: ReferenceDataEntry<C, E>,
	): E extends keyof DataEntryMap[C]
		? Promise<DataEntryMap[C][E]>
		: Promise<CollectionEntry<C> | undefined>;
	export function getEntry<
		C extends keyof ContentEntryMap,
		E extends ValidContentEntrySlug<C> | (string & {}),
	>(
		collection: C,
		slug: E,
	): E extends ValidContentEntrySlug<C>
		? Promise<CollectionEntry<C>>
		: Promise<CollectionEntry<C> | undefined>;
	export function getEntry<
		C extends keyof DataEntryMap,
		E extends keyof DataEntryMap[C] | (string & {}),
	>(
		collection: C,
		id: E,
	): E extends keyof DataEntryMap[C]
		? string extends keyof DataEntryMap[C]
			? Promise<DataEntryMap[C][E]> | undefined
			: Promise<DataEntryMap[C][E]>
		: Promise<CollectionEntry<C> | undefined>;
	export function getLiveEntry<C extends keyof LiveContentConfig['collections']>(
		collection: C,
		filter: string | LiveLoaderEntryFilterType<C>,
	): Promise<import('astro').LiveDataEntryResult<LiveLoaderDataType<C>, LiveLoaderErrorType<C>>>;

	/** Resolve an array of entry references from the same collection */
	export function getEntries<C extends keyof ContentEntryMap>(
		entries: ReferenceContentEntry<C, ValidContentEntrySlug<C>>[],
	): Promise<CollectionEntry<C>[]>;
	export function getEntries<C extends keyof DataEntryMap>(
		entries: ReferenceDataEntry<C, keyof DataEntryMap[C]>[],
	): Promise<CollectionEntry<C>[]>;

	export function render<C extends keyof AnyEntryMap>(
		entry: AnyEntryMap[C][string],
	): Promise<RenderResult>;

	export function reference<C extends keyof AnyEntryMap>(
		collection: C,
	): import('astro/zod').ZodEffects<
		import('astro/zod').ZodString,
		C extends keyof ContentEntryMap
			? ReferenceContentEntry<C, ValidContentEntrySlug<C>>
			: ReferenceDataEntry<C, keyof DataEntryMap[C]>
	>;
	// Allow generic `string` to avoid excessive type errors in the config
	// if `dev` is not running to update as you edit.
	// Invalid collection names will be caught at build time.
	export function reference<C extends string>(
		collection: C,
	): import('astro/zod').ZodEffects<import('astro/zod').ZodString, never>;

	type ReturnTypeOrOriginal<T> = T extends (...args: any[]) => infer R ? R : T;
	type InferEntrySchema<C extends keyof AnyEntryMap> = import('astro/zod').infer<
		ReturnTypeOrOriginal<Required<ContentConfig['collections'][C]>['schema']>
	>;

	type ContentEntryMap = {
		
	};

	type DataEntryMap = {
		"btsAllAssets": Record<string, {
  id: string;
  body?: string;
  collection: "btsAllAssets";
  data: InferEntrySchema<"btsAllAssets">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"btsAllDynamicData": Record<string, {
  id: string;
  body?: string;
  collection: "btsAllDynamicData";
  data: InferEntrySchema<"btsAllDynamicData">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"btsAllPools": Record<string, {
  id: string;
  body?: string;
  collection: "btsAllPools";
  data: InferEntrySchema<"btsAllPools">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"btsAssetIssuers": Record<string, {
  id: string;
  body?: string;
  collection: "btsAssetIssuers";
  data: InferEntrySchema<"btsAssetIssuers">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"btsFeeSchedule": Record<string, {
  id: string;
  body?: string;
  collection: "btsFeeSchedule";
  data: InferEntrySchema<"btsFeeSchedule">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"btsMarketData": Record<string, {
  id: string;
  body?: string;
  collection: "btsMarketData";
  data: InferEntrySchema<"btsMarketData">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"btsMinAssets": Record<string, {
  id: string;
  body?: string;
  collection: "btsMinAssets";
  data: InferEntrySchema<"btsMinAssets">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"btsMinBitassets": Record<string, {
  id: string;
  body?: string;
  collection: "btsMinBitassets";
  data: InferEntrySchema<"btsMinBitassets">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"btsMinPools": Record<string, {
  id: string;
  body?: string;
  collection: "btsMinPools";
  data: InferEntrySchema<"btsMinPools">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"btsOffers": Record<string, {
  id: string;
  body?: string;
  collection: "btsOffers";
  data: InferEntrySchema<"btsOffers">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"btsPools": Record<string, {
  id: string;
  body?: string;
  collection: "btsPools";
  data: InferEntrySchema<"btsPools">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"testAllAssets": Record<string, {
  id: string;
  body?: string;
  collection: "testAllAssets";
  data: InferEntrySchema<"testAllAssets">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"testAllDynamicData": Record<string, {
  id: string;
  body?: string;
  collection: "testAllDynamicData";
  data: InferEntrySchema<"testAllDynamicData">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"testAllPools": Record<string, {
  id: string;
  body?: string;
  collection: "testAllPools";
  data: InferEntrySchema<"testAllPools">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"testAssetIssuers": Record<string, {
  id: string;
  body?: string;
  collection: "testAssetIssuers";
  data: InferEntrySchema<"testAssetIssuers">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"testFeeSchedule": Record<string, {
  id: string;
  body?: string;
  collection: "testFeeSchedule";
  data: InferEntrySchema<"testFeeSchedule">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"testMarketData": Record<string, {
  id: string;
  body?: string;
  collection: "testMarketData";
  data: InferEntrySchema<"testMarketData">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"testMinAssets": Record<string, {
  id: string;
  body?: string;
  collection: "testMinAssets";
  data: InferEntrySchema<"testMinAssets">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"testMinBitassets": Record<string, {
  id: string;
  body?: string;
  collection: "testMinBitassets";
  data: InferEntrySchema<"testMinBitassets">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"testMinPools": Record<string, {
  id: string;
  body?: string;
  collection: "testMinPools";
  data: InferEntrySchema<"testMinPools">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"testOffers": Record<string, {
  id: string;
  body?: string;
  collection: "testOffers";
  data: InferEntrySchema<"testOffers">;
  rendered?: RenderedContent;
  filePath?: string;
}>;
"testPools": Record<string, {
  id: string;
  body?: string;
  collection: "testPools";
  data: InferEntrySchema<"testPools">;
  rendered?: RenderedContent;
  filePath?: string;
}>;

	};

	type AnyEntryMap = ContentEntryMap & DataEntryMap;

	type ExtractLoaderTypes<T> = T extends import('astro/loaders').LiveLoader<
		infer TData,
		infer TEntryFilter,
		infer TCollectionFilter,
		infer TError
	>
		? { data: TData; entryFilter: TEntryFilter; collectionFilter: TCollectionFilter; error: TError }
		: { data: never; entryFilter: never; collectionFilter: never; error: never };
	type ExtractDataType<T> = ExtractLoaderTypes<T>['data'];
	type ExtractEntryFilterType<T> = ExtractLoaderTypes<T>['entryFilter'];
	type ExtractCollectionFilterType<T> = ExtractLoaderTypes<T>['collectionFilter'];
	type ExtractErrorType<T> = ExtractLoaderTypes<T>['error'];

	type LiveLoaderDataType<C extends keyof LiveContentConfig['collections']> =
		LiveContentConfig['collections'][C]['schema'] extends undefined
			? ExtractDataType<LiveContentConfig['collections'][C]['loader']>
			: import('astro/zod').infer<
					Exclude<LiveContentConfig['collections'][C]['schema'], undefined>
				>;
	type LiveLoaderEntryFilterType<C extends keyof LiveContentConfig['collections']> =
		ExtractEntryFilterType<LiveContentConfig['collections'][C]['loader']>;
	type LiveLoaderCollectionFilterType<C extends keyof LiveContentConfig['collections']> =
		ExtractCollectionFilterType<LiveContentConfig['collections'][C]['loader']>;
	type LiveLoaderErrorType<C extends keyof LiveContentConfig['collections']> = ExtractErrorType<
		LiveContentConfig['collections'][C]['loader']
	>;

	export type ContentConfig = typeof import("./../src/content.config.js");
	export type LiveContentConfig = never;
}
